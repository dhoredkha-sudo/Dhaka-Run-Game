extends Node3D
## Obstacle / coin / power-up spawning with object pooling.
## Collision is checked here by lane + Z distance + jump/slide state,
## which is deterministic and easy to test on a phone (no physics tuning).
##
## Obstacle types:
##  bus / cng / rickshaw / barrier = must jump OR change lane (full-height)
##  barrier_low = jump over it
##  cart / puddle = slide under / jump — sliding avoids it, jumping does not
##  (puddle is a low hazard: running through it stumbles, it does not kill)
##
## Power-up types: speed_boost, magnet, shield, slowmo, distractor

var player: Node3D
var spawn_z_offset: float = -120.0
var _next_spawn_z: float = 0.0
var _items: Array = []  # dictionaries: {node, kind, lane, z, passed, is_coin...}

# Pool: reuse meshes by hiding, not freeing, where possible.
var _pool: Array = []

func reset() -> void:
	for item in _items:
		item["node"].queue_free()
	_items.clear()
	_next_spawn_z = -60.0

func _ready() -> void:
	player = get_parent().get_node_or_null("Player")

func _make_box(size: Vector3, color: Color) -> MeshInstance3D:
	var m := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	m.mesh = mesh
	var mat := StandardMaterial3D.new()
	mat.albedo_color = color
	m.set_surface_override_material(0, mat)
	return m

func _spawn_item(kind: String, lane: int, z: float) -> void:
	var root := Node3D.new()
	root.position = Vector3((lane - 1) * 2.4, 0.0, z)
	match kind:
		"bus":
			root.add_child(_make_box(Vector3(2.2, 2.6, 5.0), Color(0.1, 0.5, 0.8)))
			root.add_child(_make_box(Vector3(2.3, 0.8, 5.1), Color(1, 0.85, 0.2)))
		"cng":
			root.add_child(_make_box(Vector3(1.6, 1.4, 2.6), Color(0.1, 0.7, 0.3)))
		"rickshaw":
			root.add_child(_make_box(Vector3(1.2, 1.5, 2.0), Color(0.9, 0.2, 0.4)))
			root.add_child(_make_box(Vector3(1.4, 0.6, 0.8), Color(1, 0.8, 0.1)))
		"barrier":
			root.add_child(_make_box(Vector3(2.2, 1.1, 0.4), Color(1, 0.5, 0.1)))
		"cart":
			root.add_child(_make_box(Vector3(1.8, 1.0, 1.8), Color(0.6, 0.4, 0.2)))
			# Fruit on top: small coloured boxes.
			root.add_child(_make_box(Vector3(1.4, 0.4, 1.2), Color(1, 0.6, 0.1)))
		"puddle":
			var p := MeshInstance3D.new()
			var cm := CylinderMesh.new()
			cm.top_radius = 1.0
			cm.bottom_radius = 1.0
			cm.height = 0.05
			p.mesh = cm
			var mat := StandardMaterial3D.new()
			mat.albedo_color = Color(0.3, 0.5, 0.7)
			mat.metallic = 0.7
			mat.roughness = 0.2
			p.set_surface_override_material(0, mat)
			p.position.y = 0.03
			root.add_child(p)
		"coin":
			var c := MeshInstance3D.new()
			var cm := CylinderMesh.new()
			cm.top_radius = 0.45
			cm.bottom_radius = 0.45
			cm.height = 0.1
			c.mesh = cm
			var mat := StandardMaterial3D.new()
			mat.albedo_color = Color(1, 0.85, 0.1)
			mat.metallic = 0.6
			mat.roughness = 0.3
			c.set_surface_override_material(0, mat)
			c.rotation.z = PI / 2
			c.position.y = 1.0
			root.add_child(c)
		"powerup_speed", "powerup_magnet", "powerup_shield", "powerup_slowmo", "powerup_distractor":
			var c := MeshInstance3D.new()
			var sm := SphereMesh.new()
			sm.radius = 0.5
			sm.height = 1.0
			c.mesh = sm
			var mat := StandardMaterial3D.new()
			mat.albedo_color = Color(0.2, 0.9, 0.9) if kind != "powerup_shield" else Color(0.2, 0.4, 1.0)
			mat.emission_enabled = true
			mat.emission = mat.albedo_color
			c.set_surface_override_material(0, mat)
			c.position.y = 1.0
			root.add_child(c)
			var label := Label3D.new()
			label.text = {"powerup_speed": "⚡", "powerup_magnet": "🧲", "powerup_shield": "🛡", "powerup_slowmo": "⏱", "powerup_distractor": "📢"}[kind]
			label.font_size = 64
			label.position.y = 1.8
			root.add_child(label)
	add_child(root)
	_items.append({"node": root, "kind": kind, "lane": lane, "passed": false})

func _process(delta: float) -> void:
	if GameManager.state != GameManager.RunState.PLAYING or player == null:
		return
	var pz: float = player.position.z
	# Spawn rows ahead.
	while _next_spawn_z > pz - 140.0:
		_spawn_row(_next_spawn_z)
		_next_spawn_z -= 14.0 + randf() * 8.0
	# Update items: magnet, spin coins, collision, cleanup.
	var to_remove: Array = []
	for item in _items:
		var node: Node3D = item["node"]
		var kind: String = item["kind"]
		if kind == "coin":
			node.rotation.y += delta * 3.0
			# Magnet pulls coins in the player's lane band.
			if GameManager.has_powerup("magnet") and abs(node.position.z - pz) < 12.0:
				node.position.x = lerp(node.position.x, player.position.x, 0.25)
				node.position.z = lerp(node.position.z, pz, 0.15)
		var dz: float = abs(node.position.z - pz)
		var same_lane: bool = item["lane"] == int(player.get("lane"))
		# Collect.
		if (kind == "coin" or kind.begins_with("powerup")) and same_lane and dz < 1.2:
			if kind == "coin":
				GameManager.add_coin()
			elif kind.begins_with("powerup"):
				_apply_powerup(kind)
			to_remove.append(item)
			continue
		# Obstacle collision: player must be grounded in the same lane,
		# unless the obstacle is jumpable and the player is airborne,
		# or slideable and the player is sliding.
		if not kind.begins_with("powerup") and kind != "coin" and same_lane and dz < 1.4 and not item["passed"]:
			var p = player as CharacterBody3D
			var avoids := false
			if kind == "barrier":
				avoids = player.position.y > 0.8  # jumped over
			elif kind == "cart":
				avoids = (player as Node).get("is_sliding") == true or player.position.y > 0.8
			elif kind == "puddle":
				# Puddle never ends the run: it stumbles and costs a little gap.
				avoids = true
				GameManager.police_gap = max(GameManager.police_gap_min, GameManager.police_gap - 0.8)
				if p != null:
					p.call("stumble")
				AudioManager.play_sfx("hit")
			else:
				# bus / cng / rickshaw: full height, must change lane.
				avoids = false
			if not avoids:
				item["passed"] = true
				GameManager.register_collision()
				if p != null:
					p.call("stumble")
				# Do not remove the obstacle: the player runs past it.
			else:
				if kind != "puddle":
					item["passed"] = true
					GameManager.register_dodge()
		# Near miss: passed in an adjacent lane, very close.
		if not item["passed"] and not kind.begins_with("powerup") and kind != "coin":
			if abs(item["lane"] - int(player.get("lane"))) == 1 and dz < 1.0:
				item["passed"] = true
				GameManager.register_near_miss()
				GameManager.register_dodge()
		# Cleanup behind the police (not just behind the player, so the
		# pursuer is never seen running through a vanished bus).
		if node.position.z > pz + 30.0:
			to_remove.append(item)
	for item in to_remove:
		_items.erase(item)
		item["node"].queue_free()

func _apply_powerup(kind: String) -> void:
	match kind:
		"powerup_speed":
			GameManager.activate_powerup("speed_boost", 5.0)
		"powerup_magnet":
			GameManager.activate_powerup("magnet", 8.0)
		"powerup_shield":
			GameManager.activate_powerup("shield", 12.0)
		"powerup_slowmo":
			GameManager.activate_powerup("slowmo", 4.0)
		"powerup_distractor":
			GameManager.activate_powerup("distractor", 0.0)

func _spawn_row(z: float) -> void:
	# Never block all three lanes with a full-height obstacle.
	var roll := randf()
	if roll < 0.55:
		# One obstacle + a coin line in another lane.
		var obs_lane := randi() % 3
		var obs: String = ["bus", "cng", "rickshaw", "barrier", "cart", "puddle"][randi() % 6]
		_spawn_item(obs, obs_lane, z)
		var coin_lane := (obs_lane + 1 + randi() % 2) % 3
		for i in range(4):
			_spawn_item("coin", coin_lane, z - 2.0 - i * 2.0)
	elif roll < 0.75:
		# Two obstacles, one free lane.
		var free_lane := randi() % 3
		for lane in range(3):
			if lane != free_lane:
				_spawn_item(["cng", "barrier", "cart"][randi() % 3], lane, z)
		for i in range(3):
			_spawn_item("coin", free_lane, z - 2.0 - i * 2.0)
	elif roll < 0.88:
		# Coin arc only — a breather row.
		var lane := randi() % 3
		for i in range(5):
			_spawn_item("coin", lane, z - i * 2.0)
	else:
		# Power-up row, guarded by a coin line.
		var pu: String = ["powerup_speed", "powerup_magnet", "powerup_shield", "powerup_slowmo", "powerup_distractor"][randi() % 5]
		var lane := randi() % 3
		_spawn_item(pu, lane, z)
		for i in range(3):
			_spawn_item("coin", lane, z - 3.0 - i * 2.0)
