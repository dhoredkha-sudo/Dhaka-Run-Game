extends Node
## Original Bengali dialogue system.
## All lines below are short original lines written for this game.
## They are NOT reproduced movie dialogue. Voice files are optional:
## put a .wav with the same key in res://audio/voices/ to play it,
## otherwise only the subtitle is shown (see AudioManager).

signal subtitle_shown(text: String, speaker: String)

# Cooldowns stop spam: same context cannot repeat within X seconds.
var _last_said: Dictionary = {}
var _cooldowns: Dictionary = {
	"chase_start": 2.0, "close_police": 4.0, "near_miss": 5.0,
	"special_item": 6.0, "new_env": 8.0, "jump": 7.0,
	"lose": 1.0, "highscore": 1.0,
}

var LINES: Dictionary = {
	"chase_start": [
		["পুলিশ", "এই দাঁড়া! আজকে আর পালানোর রাস্তা নাই!"],
		["পুলিশ", "ঢাকার রাস্তা চিনিস, কিন্তু পুলিশের হিসাব চিনিস না!"],
		["পুলিশ", "থাম! সামনে কিন্তু শেষ গলি!"],
		["পুলিশ", "দৌড়া যত পারিস, আইন কিন্তু পেছনেই আছে!"],
		["রানার", "আরে, আমি তো শুধু হাঁটতে বেরিয়েছিলাম!"],
		["পুলিশ", "ব্যাগটা রেখে গেলেই গল্প শেষ, নইলে দৌড় চলবে!"],
	],
	"close_police": [
		["রানার", "আরে ভাই, একটু স্পিড কমান!"],
		["রানার", "ওস্তাদ, রাস্তা তো শেষ হয়ে গেল!"],
		["পুলিশ", "আর দুই কদম! এবার ধরেই ফেলব!"],
		["রানার", "এই রিকশাওয়ালা মামা, সাইড দেন!"],
		["পুলিশ", "পেছনে তাকাস না, সামনে দেখ!"],
		["রানার", "আজকে কপালটাই খারাপ!"],
	],
	"near_miss": [
		["রানার", "উফ! একটুর জন্য বেঁচে গেলাম!"],
		["পুলিশ", "এত কাছে এসেও ফসকে গেল!"],
		["রানার", "বাসের হর্ন শুনলেই আমার হার্টবিট বাড়ে!"],
		["পুলিশ", "ভাগ্য ভালো, পরের বার আর না!"],
		["রানার", "সিনেমার মতো বাঁচলাম, তাই না?"],
	],
	"special_item": [
		["রানার", "এইটা পেলে একটু দম নেওয়া যাবে!"],
		["পুলিশ", "ওইটা ছুঁস না, ওইটা আমার প্রমাণ!"],
		["রানার", "কয়েন পেলে দৌড় আরেকটু মজা লাগে!"],
		["পুলিশ", "কয়েন কুড়িয়ে পালানো যাবে না!"],
		["রানার", "আজকের বাজারটা ভালোই জমেছে!"],
	],
	"new_env": [
		["রানার", "এই গলিটা তো পুরান ঢাকার মতো লাগে!"],
		["পুলিশ", "ফ্লাইওভারে উঠলেই আর লুকানোর জায়গা নাই!"],
		["রানার", "বাজারের ভিড়ে হারিয়ে যাওয়া যাবে!"],
		["পুলিশ", "বৃষ্টিতে রাস্তা পিছলা, সাবধানে দৌড়া!"],
		["রানার", "রাতের বাজার মানেই আলো আর ভিড়!"],
		["পুলিশ", "যে রাস্তায় যাস, আমি সেই রাস্তায় আসছি!"],
	],
	"jump": [
		["রানার", "লাফ! একদম সিনেমার হিরোর মতো!"],
		["পুলিশ", "লাফ দিয়ে পার পাবি ভেবেছিস?"],
		["রানার", "ব্যারিকেডের ওপর দিয়ে উড়ে গেলাম!"],
		["পুলিশ", "উঁচুতে উঠলেই চোখে পড়বি বেশি!"],
	],
	"lose": [
		["পুলিশ", "দৌড় শেষ, এবার জবাব দেওয়ার পালা!"],
		["রানার", "ঠিক আছে, ঠিক আছে… ধরা পড়ে গেলাম!"],
		["পুলিশ", "ঢাকার পুলিশকে ফাঁকি দেওয়া এত সহজ না!"],
		["রানার", "পরের বার আরো জোরে দৌড়াব, কথা দিলাম!"],
		["পুলিশ", "চলো, এবার থানার চা খেয়ে গল্প করি!"],
	],
	"highscore": [
		["রানার", "নতুন রেকর্ড! আজকে আমি চ্যাম্পিয়ন!"],
		["পুলিশ", "এই রেকর্ডটা ভাঙতে আমিও আবার আসব!"],
		["রানার", "ঢাকা রান-এর সেরা দৌড়বিদ আমি!"],
		["পুলিশ", "ভালো দৌড়েছিস, স্বীকার করতেই হবে!"],
	],
}

func say(context: String) -> void:
	if not LINES.has(context):
		return
	var now := Time.get_ticks_msec() / 1000.0
	var cd: float = float(_cooldowns.get(context, 4.0))
	if _last_said.has(context) and now - float(_last_said[context]) < cd:
		return
	_last_said[context] = now
	var pool: Array = LINES[context]
	var pick: Array = pool[randi() % pool.size()]
	subtitle_shown.emit(pick[1], pick[0])
	# Optional voice: res://audio/voices/<context>_<index>.wav if the developer adds it.
	AudioManager.play_dialogue(context)
