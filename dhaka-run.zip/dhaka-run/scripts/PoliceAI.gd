extends CharacterBody3D
## Police pursuer. He does NOT teleport: his world position is the
## player's position plus the current gap from GameManager.
## When the gap reaches the catch threshold, GameManager ends the run,
## and this script plays the catch pose (arms up) in Main's game-over flow.

@export var catch_gap: float = 2.5

var run_bob: float = 0.0
@onready var leg_l: MeshInstance3D = $LegL
@onready var leg_r: MeshInstance3D = $LegR
@onready var arm_l: MeshInstance3D = $ArmL
@onready var arm_r: MeshInstance3D = $ArmR

func _physics_process(delta: float) -> void:
	if GameManager.state != GameManager.RunState.PLAYING:
		return
	# Follow the player node (set as sibling in Main; resolved by parent).
	var player := get_parent().get_node_or_null("Player")
	if player == null:
		return
	# Stay in the player's lane, a gap behind. Lerp so a shrinking gap
	# visibly closes in, instead of snapping.
	var target_z: float = player.position.z + GameManager.police_gap
	position.z = lerp(position.z, target_z, 1.0 - exp(-8.0 * delta))
	position.x = lerp(position.x, player.position.x, 1.0 - exp(-6.0 * delta))
	position.y = 0.0
	run_bob += delta * GameManager.speed * 1.2
	var swing := sin(run_bob) * 0.65
	leg_l.rotation.x = swing
	leg_r.rotation.x = -swing
	arm_l.rotation.x = -swing * 0.8
	arm_r.rotation.x = swing * 0.8
	# Confident posture: slight forward lean, cap stays level.
	rotation.x = 0.08
	move_and_slide()
