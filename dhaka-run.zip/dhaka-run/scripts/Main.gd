extends Node3D
## Scene root: camera, lights, player, police, road, spawner, UI.
## start_run() resets every system in order, so Restart never
## carries over obstacles, coins or police distance from the last run.

@onready var player: CharacterBody3D = $Player
@onready var police: CharacterBody3D = $Police
@onready var road: Node3D = $RoadGenerator
@onready var spawner: Node3D = $ObstacleSpawner
@onready var ui: CanvasLayer = $UIManager

func _ready() -> void:
	# Camera: behind and above the player, looking down the road (-Z).
	# Portrait framing: a slightly higher angle so obstacles ahead are visible.
	var cam := $Camera3D
	cam.position = Vector3(0, 6.5, 9.5)
	cam.rotation_degrees = Vector3(-18, 0, 0)
	road.call("reset")
	spawner.call("reset")
	GameManager.to_menu()
	# Theme-change hook: Main does not need to do anything else, but
	# keeping the connection here documents the environment flow.
	if road.has_signal("environment_changed"):
		road.connect("environment_changed", _on_env_changed)

func start_run() -> void:
	player.position = Vector3(0, 0, 0)
	player.set("lane", 1)
	player.set("target_x", 0.0)
	player.set("is_sliding", false)
	player.set("vertical_velocity", 0.0)
	police.position = Vector3(0, 0, 12.0)
	road.call("reset")
	spawner.call("reset")
	GameManager.start_run()

func _on_env_changed(_id: String, _bangla: String) -> void:
	# Subtitle + fog are handled in RoadGenerator / DialogueManager.
	pass

func _input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
		if GameManager.state == GameManager.RunState.PLAYING or GameManager.state == GameManager.RunState.PAUSED:
			GameManager.pause_toggle()
