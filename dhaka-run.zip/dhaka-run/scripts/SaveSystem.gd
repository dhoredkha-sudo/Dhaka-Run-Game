extends Node
## Local-only save system. No login, no internet required.
## Uses Godot's user:// ConfigFile. Nothing is sent anywhere.

const SAVE_PATH := "user://dhaka_run_save.cfg"

var best_score: int = 0
var best_distance: float = 0.0
var total_coins: int = 0
var unlocked_outfits: Array = ["street_default"]
var selected_outfit: String = "street_default"
var selected_character: String = "runner"
var music_volume: float = 0.8
var sfx_volume: float = 0.9
var dialogue_volume: float = 1.0
var completed_missions: Dictionary = {}

func _ready() -> void:
	load_game()

func load_game() -> void:
	var cfg := ConfigFile.new()
	if cfg.load(SAVE_PATH) != OK:
		return
	best_score = int(cfg.get_value("progress", "best_score", 0))
	best_distance = float(cfg.get_value("progress", "best_distance", 0.0))
	total_coins = int(cfg.get_value("progress", "total_coins", 0))
	unlocked_outfits = Array(cfg.get_value("progress", "unlocked_outfits", ["street_default"]))
	selected_outfit = str(cfg.get_value("progress", "selected_outfit", "street_default"))
	selected_character = str(cfg.get_value("progress", "selected_character", "runner"))
	music_volume = float(cfg.get_value("settings", "music_volume", 0.8))
	sfx_volume = float(cfg.get_value("settings", "sfx_volume", 0.9))
	dialogue_volume = float(cfg.get_value("settings", "dialogue_volume", 1.0))
	completed_missions = Dictionary(cfg.get_value("progress", "completed_missions", {}))

func save_game() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("progress", "best_score", best_score)
	cfg.set_value("progress", "best_distance", best_distance)
	cfg.set_value("progress", "total_coins", total_coins)
	cfg.set_value("progress", "unlocked_outfits", unlocked_outfits)
	cfg.set_value("progress", "selected_outfit", selected_outfit)
	cfg.set_value("progress", "selected_character", selected_character)
	cfg.set_value("settings", "music_volume", music_volume)
	cfg.set_value("settings", "sfx_volume", sfx_volume)
	cfg.set_value("settings", "dialogue_volume", dialogue_volume)
	cfg.set_value("progress", "completed_missions", completed_missions)
	cfg.save(SAVE_PATH)

func add_coins(amount: int) -> void:
	total_coins += amount
	save_game()

func spend_coins(amount: int) -> bool:
	if total_coins < amount:
		return false
	total_coins -= amount
	save_game()
	return true

func unlock_outfit(outfit_id: String) -> void:
	if outfit_id not in unlocked_outfits:
		unlocked_outfits.append(outfit_id)
		save_game()
