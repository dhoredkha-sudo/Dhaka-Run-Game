extends CharacterBody3D
## Player: 3 lanes, swipe + keyboard, jump / slide physics, stumble.
## Forward motion is real movement in -Z; distance is measured from it.

@export var lane_width: float = 2.4
@export var lane_change_speed: float = 14.0
@export var jump_velocity: float = 9.5
@export var gravity: float = 26.0

var lane: int = 1  # 0 = left, 1 = centre, 2 = right
var target_x: float = 0.0
var vertical_velocity: float = 0.0
var is_sliding: bool = false
var slide_timer: float = 0.0
var is_grounded: bool = true
var stumble_timer: float = 0.0
var run_bob: float = 0.0

var _touch_start: Vector2 = Vector2.ZERO
var _touch_id: int = -1
var _swipe_done: bool = false

@onready var body_mesh: MeshInstance3D = $Body
@onready var head_mesh: MeshInstance3D = $Head
@onready var leg_l: MeshInstance3D = $LegL
@onready var leg_r: MeshInstance3D = $LegR
@onready var arm_l: MeshInstance3D = $ArmL
@onready var arm_r: MeshInstance3D = $ArmR

func _ready() -> void:
	target_x = lane_to_x(lane)
	apply_outfit()

func lane_to_x(l: int) -> float:
	return (l - 1) * lane_width

func apply_outfit() -> void:
	# Colours come from the outfit catalogue; no model swap is faked.
	# The mesh stays the same character, only its shirt colour changes.
	for item in MissionManager.outfit_catalog():
		if item["id"] == SaveSystem.selected_outfit:
			var mat := StandardMaterial3D.new()
			mat.albedo_color = item["color"]
			body_mesh.set_surface_override_material(0, mat)
			break

func move_left() -> void:
	if lane > 0:
		lane -= 1
		target_x = lane_to_x(lane)

func move_right() -> void:
	if lane < 2:
		lane += 1
		target_x = lane_to_x(lane)

func jump() -> void:
	if is_grounded and not is_sliding:
		vertical_velocity = jump_velocity
		is_grounded = false
		AudioManager.play_sfx("jump")
		DialogueManager.say("jump")

func slide() -> void:
	if not is_grounded:
		# Fast-fall: slamming down feels responsive on a phone.
		vertical_velocity = -18.0
		return
	if not is_sliding:
		is_sliding = true
		slide_timer = 0.7
		AudioManager.play_sfx("slide")

func stumble() -> void:
	stumble_timer = 0.4

func _input(event: InputEvent) -> void:
	if GameManager.state != GameManager.RunState.PLAYING:
		return
	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_LEFT, KEY_A:
				move_left()
			KEY_RIGHT, KEY_D:
				move_right()
			KEY_UP, KEY_W, KEY_SPACE:
				jump()
			KEY_DOWN, KEY_S:
				slide()
	if event is InputEventScreenTouch:
		if event.pressed and _touch_id == -1:
			_touch_id = event.index
			_touch_start = event.position
			_swipe_done = false
		elif not event.pressed and event.index == _touch_id:
			_touch_id = -1
	if event is InputEventScreenDrag and event.index == _touch_id and not _swipe_done:
		var d: Vector2 = (event as InputEventScreenDrag).position - _touch_start
		if d.length() < 40:
			return
		_swipe_done = true
		if abs(d.x) > abs(d.y):
			if d.x > 0:
				move_right()
			else:
				move_left()
		else:
			if d.y < 0:
				jump()
			else:
				slide()

func _physics_process(delta: float) -> void:
	if GameManager.state == GameManager.RunState.PLAYING:
		# Forward run.
		position.z -= GameManager.speed * delta
		# Lane lerp (smooth, frame-rate independent).
		position.x = lerp(position.x, target_x, 1.0 - exp(-lane_change_speed * delta))
		# Jump / gravity.
		if not is_grounded:
			vertical_velocity -= gravity * delta
			position.y += vertical_velocity * delta
			if position.y <= 0.0:
				position.y = 0.0
				vertical_velocity = 0.0
				is_grounded = true
		if is_sliding:
			slide_timer -= delta
			if slide_timer <= 0.0:
				is_sliding = false
		if stumble_timer > 0.0:
			stumble_timer -= delta
		_animate(delta)
	# CharacterBody3D is used so Area3D / physics layers stay consistent,
	# but forward motion above is authoritative for the runner.
	move_and_slide()

func _animate(delta: float) -> void:
	run_bob += delta * GameManager.speed * 1.2
	var swing := sin(run_bob) * 0.7
	leg_l.rotation.x = swing
	leg_r.rotation.x = -swing
	arm_l.rotation.x = -swing
	arm_r.rotation.x = swing
	# Lean into a lane change.
	var lean := (target_x - position.x) * 0.12
	rotation.z = lerp(rotation.z, -lean, 0.2)
	# Slide = squash, stumble = shake.
	if is_sliding:
		scale.y = lerp(scale.y, 0.55, 0.3)
		rotation.x = 0.25
	else:
		scale.y = lerp(scale.y, 1.0, 0.2)
		rotation.x = 0.0
	if stumble_timer > 0.0:
		rotation.z += sin(Time.get_ticks_msec() * 0.05) * 0.08
	# Panic: head tilts back when the police are very close.
	var gap := GameManager.police_gap
	head_mesh.rotation.x = -0.3 if gap < 6.0 else 0.0
