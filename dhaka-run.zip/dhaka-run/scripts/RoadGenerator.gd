extends Node3D
## Procedural endless road. Segments are pooled, not created/destroyed
## every frame. Themes cycle: Old Dhaka, Commercial Road, Flyover,
## Bazaar, Rain Street, Night Market.
## All brands / shop names below are fictional.

const SEGMENT_LENGTH: float = 20.0
const SEGMENTS_AHEAD: int = 8

signal environment_changed(theme_name: String, theme_bangla: String)

var themes: Array = [
	{"id": "old_dhaka", "bangla": "পুরান ঢাকা", "road": Color(0.22, 0.22, 0.23), "building": Color(0.75, 0.65, 0.45), "fog": Color(0.85, 0.8, 0.7), "shops": ["আল-মদিনা চা ঘর", "পুরান ঢাকা ফল বাজার", "নবাব স্টোর"]},
	{"id": "commercial", "bangla": "বাণিজ্যিক সড়ক", "road": Color(0.18, 0.18, 0.2), "building": Color(0.45, 0.55, 0.7), "fog": Color(0.7, 0.78, 0.9), "shops": ["স্বপ্ন বাজার", "ঢাকা ইলেকট্রনিক্স", "রূপসা ফ্যাশন"]},
	{"id": "flyover", "bangla": "ফ্লাইওভার", "road": Color(0.25, 0.25, 0.27), "building": Color(0.5, 0.5, 0.55), "fog": Color(0.75, 0.82, 0.92), "shops": ["ফ্লাইওভার চা স্টল", "আকাশ টাওয়ার"]},
	{"id": "bazaar", "bangla": "লোকাল বাজার", "road": Color(0.28, 0.24, 0.2), "building": Color(0.7, 0.5, 0.35), "fog": Color(0.9, 0.82, 0.65), "shops": ["কাঁচা বাজার", "মাছ বাজার কর্নার", "সবজি ভান্ডার"]},
	{"id": "rain", "bangla": "বৃষ্টির রাস্তা", "road": Color(0.15, 0.17, 0.2), "building": Color(0.4, 0.45, 0.5), "fog": Color(0.6, 0.68, 0.78), "shops": ["বৃষ্টি চা ঘর", "ছাতা স্টোর"]},
	{"id": "night_market", "bangla": "রাতের বাজার", "road": Color(0.12, 0.12, 0.18), "building": Color(0.3, 0.3, 0.45), "fog": Color(0.1, 0.12, 0.25), "shops": ["রাতের ফুচকা", "নিয়ন ফ্যাশন", "চটপটি হাউস"]},
]

var segments: Array = []
var next_segment_z: float = 0.0
var current_theme_index: int = 0
var distance_since_theme: float = 0.0
var player: Node3D

func _ready() -> void:
	player = get_parent().get_node_or_null("Player")

func reset() -> void:
	for s in segments:
		s.queue_free()
	segments.clear()
	next_segment_z = 20.0
	current_theme_index = 0
	distance_since_theme = 0.0
	# Pre-fill ahead of the player (player runs towards -Z).
	for i in range(SEGMENTS_AHEAD):
		_spawn_segment()

func _spawn_segment() -> void:
	var seg := Node3D.new()
	seg.position.z = next_segment_z
	next_segment_z -= SEGMENT_LENGTH
	_build_segment(seg, themes[current_theme_index])
	add_child(seg)
	segments.append(seg)

func _build_segment(seg: Node3D, theme: Dictionary) -> void:
	# Road slab.
	var road := MeshInstance3D.new()
	var road_mesh := BoxMesh.new()
	road_mesh.size = Vector3(9.0, 0.2, SEGMENT_LENGTH)
	road.mesh = road_mesh
	var road_mat := StandardMaterial3D.new()
	road_mat.albedo_color = theme["road"]
	road.set_surface_override_material(0, road_mat)
	road.position.y = -0.1
	seg.add_child(road)
	# Lane divider dashes (small white boxes).
	for dz in [-7.5, -2.5, 2.5, 7.5]:
		var dash := MeshInstance3D.new()
		var dm := BoxMesh.new()
		dm.size = Vector3(0.15, 0.02, 2.0)
		dash.mesh = dm
		var dmat := StandardMaterial3D.new()
		dmat.albedo_color = Color(1, 1, 0.85)
		dash.set_surface_override_material(0, dmat)
		dash.position = Vector3(0, 0.02, dz)
		seg.add_child(dash)
	# Side buildings + fictional Bangla shop signs (Label3D).
	var shops: Array = theme["shops"]
	for side in [-1, 1]:
		for i in range(3):
			var b := MeshInstance3D.new()
			var bm := BoxMesh.new()
			bm.size = Vector3(2.5, 3.0 + float(i % 3), 5.0)
			b.mesh = bm
			var bmat := StandardMaterial3D.new()
			bmat.albedo_color = theme["building"]
			b.set_surface_override_material(0, bmat)
			b.position = Vector3(side * 7.0, bm.size.y / 2.0, -6.0 + i * 6.0)
			seg.add_child(b)
			var sign := Label3D.new()
			sign.text = shops[(i + (0 if side < 0 else 1)) % shops.size()]
			sign.font_size = 48
			sign.position = Vector3(side * 5.4, 2.8, -6.0 + i * 6.0)
			sign.rotation.y = -PI / 2 if side < 0 else PI / 2
			# Green-white Bangladesh-inspired signage frame colour is
			# applied via outline; the Label3D itself stays readable.
			sign.outline_size = 8
			sign.modulate = Color(0.1, 0.6, 0.25) if side < 0 else Color(1, 1, 1)
			seg.add_child(sign)
	# Streetlight pole (simple, pooled with the segment).
	var pole := MeshInstance3D.new()
	var pm := CylinderMesh.new()
	pm.top_radius = 0.08
	pm.bottom_radius = 0.08
	pm.height = 5.0
	pole.mesh = pm
	pole.position = Vector3(5.2, 2.5, 0)
	seg.add_child(pole)
	# Rain theme: puddle discs with high gloss (reflection is faked
	# with metallic + low roughness for mobile performance).
	if theme["id"] == "rain":
		for i in range(3):
			var puddle := MeshInstance3D.new()
			var pud_mesh := CylinderMesh.new()
			pud_mesh.top_radius = 0.9
			pud_mesh.bottom_radius = 0.9
			pud_mesh.height = 0.02
			puddle.mesh = pud_mesh
			var pmat := StandardMaterial3D.new()
			pmat.albedo_color = Color(0.4, 0.55, 0.7)
			pmat.metallic = 0.8
			pmat.roughness = 0.15
			puddle.set_surface_override_material(0, pmat)
			puddle.position = Vector3(float((i - 1) * 2), 0.03, -5.0 + i * 5.0)
			seg.add_child(puddle)

func _process(delta: float) -> void:
	if GameManager.state != GameManager.RunState.PLAYING or player == null:
		return
	# Recycle segments behind the player, spawn ahead.
	while not segments.is_empty() and segments[0].position.z > player.position.z + 25.0:
		var old = segments.pop_front()
		old.queue_free()
		_spawn_segment()
	# Theme change every ~300 m.
	distance_since_theme += GameManager.speed * delta
	if distance_since_theme > 300.0:
		distance_since_theme = 0.0
		current_theme_index = (current_theme_index + 1) % themes.size()
		var t: Dictionary = themes[current_theme_index]
		environment_changed.emit(t["id"], t["bangla"])
		DialogueManager.say("new_env")
		# Fog colour follows the theme (set on the scene's WorldEnvironment in Main).
		var env := get_parent().get_node_or_null("WorldEnvironment")
		if env != null and env.environment != null:
			env.environment.fog_light_color = t["fog"]
