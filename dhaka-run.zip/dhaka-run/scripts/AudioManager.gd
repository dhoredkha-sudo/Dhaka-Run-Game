extends Node
## Audio manager with separate music / SFX / dialogue volumes.
## Included .wav files in res://audio/ are original synthesized tones
## made for this project (see tools/make_sounds.py in README).
## Replace any file with a licensed recording of the same name and
## the game will use it automatically — no code change needed.
## Missing files are skipped silently, never crash the game.

var _music_player: AudioStreamPlayer
var _sfx_player: AudioStreamPlayer
var _dialogue_player: AudioStreamPlayer

func _ready() -> void:
	_music_player = AudioStreamPlayer.new()
	_sfx_player = AudioStreamPlayer.new()
	_dialogue_player = AudioStreamPlayer.new()
	add_child(_music_player)
	add_child(_sfx_player)
	add_child(_dialogue_player)
	apply_volumes()
	# Music is started by Main when a run/menu begins, not here,
	# so a missing file does not block startup.

func apply_volumes() -> void:
	_music_player.volume_db = linear_to_db(clamp(SaveSystem.music_volume, 0.0, 1.0))
	_sfx_player.volume_db = linear_to_db(clamp(SaveSystem.sfx_volume, 0.0, 1.0))
	_dialogue_player.volume_db = linear_to_db(clamp(SaveSystem.dialogue_volume, 0.0, 1.0))

func _load_wav(path: String) -> AudioStream:
	if not ResourceLoader.exists(path):
		return null
	var res = load(path)
	if res is AudioStream:
		return res
	return null

func play_sfx(name: String) -> void:
	var stream := _load_wav("res://audio/%s.wav" % name)
	if stream == null:
		return
	_sfx_player.stream = stream
	_sfx_player.play()

func play_dialogue(context: String) -> void:
	# Voice acting is optional. If no voice file exists, subtitles carry it.
	var stream := _load_wav("res://audio/voices/%s.wav" % context)
	if stream == null:
		return
	_dialogue_player.stream = stream
	_dialogue_player.play()

func start_music() -> void:
	var stream := _load_wav("res://audio/music_loop.wav")
	if stream == null:
		return
	if _music_player.stream == stream and _music_player.playing:
		return
	_music_player.stream = stream
	_music_player.play()

func stop_music() -> void:
	_music_player.stop()

static func linear_to_db(v: float) -> float:
	if v <= 0.001:
		return -80.0
	return 20.0 * log(v) / log(10.0)
