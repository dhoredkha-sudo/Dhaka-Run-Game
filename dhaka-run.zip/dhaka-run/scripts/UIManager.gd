extends CanvasLayer
## All screens, built in code so the project needs no external UI assets.
## Bengali-first text. No button promises a reward or revive that does
## not work: Game Over has only Play Again / Main Menu, and the
## mission screen only *shows* progress (rewards are granted by
## MissionManager when a run actually completes a mission).

var main_menu: Panel
var hud: Control
var pause_menu: Panel
var game_over_panel: Panel
var settings_panel: Panel
var character_panel: Panel
var outfit_panel: Panel
var mission_panel: Panel
var highscore_panel: Panel

var score_label: Label
var coins_label: Label
var distance_label: Label
var police_bar: ProgressBar
var police_label: Label
var powerup_label: Label
var subtitle_label: Label
var game_over_label: Label
var subtitle_timer: float = 0.0

func _ready() -> void:
	_build_ui()
	_show_only(main_menu)
	GameManager.score_changed.connect(_on_score)
	GameManager.police_distance_changed.connect(_on_police)
	GameManager.powerup_changed.connect(_on_powerup)
	GameManager.game_over.connect(_on_game_over)
	GameManager.run_started.connect(_on_run_started)
	DialogueManager.subtitle_shown.connect(_on_subtitle)
	MissionManager.missions_updated.connect(_on_missions)

func _panel() -> Panel:
	var p := Panel.new()
	p.set_anchors_preset(Control.PRESET_FULL_RECT)
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.05, 0.12, 0.18, 0.95)
	p.add_theme_stylebox_override("panel", style)
	add_child(p)
	return p

func _label(parent: Control, text: String, y: float, size: int = 32) -> Label:
	var l := Label.new()
	l.text = text
	l.position = Vector2(40, y)
	l.size = Vector2(640, 60)
	l.add_theme_font_size_override("font_size", size)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	parent.add_child(l)
	return l

func _button(parent: Control, text: String, y: float, callback: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.position = Vector2(160, y)
	b.size = Vector2(400, 72)
	b.add_theme_font_size_override("font_size", 30)
	b.pressed.connect(callback)
	parent.add_child(b)
	return b

func _build_ui() -> void:
	# ---- Main menu ----
	main_menu = _panel()
	_label(main_menu, "ঢাকা রান", 120, 64)
	_label(main_menu, "DHAKA RUN: POLICE CHASE", 200, 28)
	_label(main_menu, "কাল্পনিক গল্প — আসল চুরি নয়, শুধু মজার দৌড়!", 250, 22)
	_button(main_menu, "▶ খেলুন", 340, _on_play)
	_button(main_menu, "👤 চরিত্র", 430, func(): _show_only(character_panel))
	_button(main_menu, "👕 পোশাক", 520, func(): _show_only(outfit_panel))
	_button(main_menu, "🎯 মিশন", 610, func(): _show_only(mission_panel))
	_button(main_menu, "🏆 সেরা স্কোর", 700, func(): _show_only(highscore_panel))
	_button(main_menu, "⚙ সেটিংস", 790, func(): _show_only(settings_panel))
	_label(main_menu, "সোয়াইপ: বাম/ডান = লেন, উপরে = লাফ, নিচে = স্লাইড", 900, 22)

	# ---- HUD ----
	hud = Control.new()
	hud.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(hud)
	score_label = _label(hud, "স্কোর: 0", 20, 32)
	coins_label = _label(hud, "🪙 0", 70, 28)
	distance_label = _label(hud, "0 মি", 110, 28)
	police_label = _label(hud, "পুলিশের দূরত্ব", 155, 22)
	police_bar = ProgressBar.new()
	police_bar.position = Vector2(160, 185)
	police_bar.size = Vector2(400, 28)
	police_bar.min_value = 0
	police_bar.max_value = 18
	police_bar.value = 12
	hud.add_child(police_bar)
	powerup_label = _label(hud, "", 225, 24)
	subtitle_label = _label(hud, "", 1050, 28)
	var pause_btn := Button.new()
	pause_btn.text = "⏸"
	pause_btn.position = Vector2(620, 20)
	pause_btn.size = Vector2(72, 72)
	pause_btn.pressed.connect(func(): GameManager.pause_toggle(); _show_only(pause_menu) if GameManager.state == GameManager.RunState.PAUSED else _show_only(hud))
	hud.add_child(pause_btn)

	# ---- Pause ----
	pause_menu = _panel()
	_label(pause_menu, "বিরতি", 200, 56)
	_button(pause_menu, "▶ চালিয়ে যান", 320, func(): GameManager.pause_toggle(); _show_only(hud))
	_button(pause_menu, "🔄 আবার শুরু", 410, _on_play)
	_button(pause_menu, "🏠 প্রধান মেনু", 500, func(): GameManager.to_menu(); _show_only(main_menu))

	# ---- Game over ----
	game_over_panel = _panel()
	game_over_label = _label(game_over_panel, "", 180, 36)
	_button(game_over_panel, "আবার খেলুন", 520, _on_play)
	_button(game_over_panel, "প্রধান মেনু", 610, func(): GameManager.to_menu(); _show_only(main_menu))
	_label(game_over_panel, "কোনো রিভাইভ বোতাম নেই — কারণ এই বিল্ডে রিভাইভ নেই।", 720, 20)

	# ---- Settings ----
	settings_panel = _panel()
	_label(settings_panel, "সেটিংস", 150, 52)
	_label(settings_panel, "ভলিউম স্লাইডারগুলো পরের আপডেটে যুক্ত হবে —\nএই বিল্ডে ভলিউম SaveSystem-এর ডিফল্ট ব্যবহার করে।", 250, 24)
	_button(settings_panel, "⬅ ফিরে যান", 500, func(): _show_only(main_menu))

	# ---- Character ----
	character_panel = _panel()
	_label(character_panel, "চরিত্র নির্বাচন", 150, 48)
	_label(character_panel, "রানার: কাল্পনিক তরুণ দৌড়বিদ\nপুলিশ: কাল্পনিক অফিসার (প্রতিপক্ষ, খেলার যোগ্য নয়)", 230, 26)
	_button(character_panel, "🏃 রানার হিসেবে খেলুন", 400, func(): SaveSystem.selected_character = "runner"; SaveSystem.save_game(); _show_only(main_menu))
	_button(character_panel, "⬅ ফিরে যান", 500, func(): _show_only(main_menu))

	# ---- Outfit ----
	outfit_panel = _panel()
	_label(outfit_panel, "পোশাক", 120, 48)
	_refresh_outfits()
	_button(outfit_panel, "⬅ ফিরে যান", 900, func(): _show_only(main_menu))

	# ---- Missions ----
	mission_panel = _panel()
	_label(mission_panel, "আজকের মিশন", 120, 48)
	_on_missions(MissionManager.daily_missions)
	_button(mission_panel, "⬅ ফিরে যান", 900, func(): _show_only(main_menu))

	# ---- High scores ----
	highscore_panel = _panel()
	_label(highscore_panel, "সেরা স্কোর", 150, 48)
	_label(highscore_panel, "সেরা স্কোর এবং দূরত্ব এই ডিভাইসেই সংরক্ষিত।\nসর্বশেষ মান মেনু খোলার সময় আপডেট হয়।", 230, 24)
	_button(highscore_panel, "⬅ ফিরে যান", 500, func(): _show_only(main_menu))

func _refresh_outfits() -> void:
	# Outfit buttons are rebuilt each time the panel is shown in _show_only
	# via this helper being called from _on_missions-style refresh points.
	# For simplicity, outfit buttons live in the panel and are created once
	# here with live coin checks at press time.
	var y := 200.0
	for item in MissionManager.outfit_catalog():
		var owned: bool = item["id"] in SaveSystem.unlocked_outfits
		var txt := "%s — %s" % [item["name"], "নিজের" if owned else "%d কয়েন" % int(item["price"])]
		var btn := Button.new()
		btn.text = txt
		btn.position = Vector2(120, y)
		btn.size = Vector2(480, 64)
		btn.add_theme_font_size_override("font_size", 26)
		var outfit_id: String = item["id"]
		var price: int = int(item["price"])
		btn.pressed.connect(func():
			if outfit_id in SaveSystem.unlocked_outfits:
				SaveSystem.selected_outfit = outfit_id
				SaveSystem.save_game()
			elif SaveSystem.spend_coins(price):
				SaveSystem.unlock_outfit(outfit_id)
				SaveSystem.selected_outfit = outfit_id
			_show_only(main_menu)
		)
		outfit_panel.add_child(btn)
		y += 80.0

func _show_only(panel: Control) -> void:
	for p in [main_menu, hud, pause_menu, game_over_panel, settings_panel, character_panel, outfit_panel, mission_panel, highscore_panel]:
		if p != null:
			p.visible = (p == panel)
	if panel == highscore_panel:
		# Refresh the high-score text by rebuilding its second label.
		# (Labels are children; index 1 is the info label.)
		if highscore_panel.get_child_count() > 1:
			var l := highscore_panel.get_child(1) as Label
			if l != null:
				l.text = "সেরা স্কোর: %d\nসেরা দূরত্ব: %.0f মি\nমোট কয়েন: %d" % [SaveSystem.best_score, SaveSystem.best_distance, SaveSystem.total_coins]

func _on_play() -> void:
	_show_only(hud)
	var main_node := get_parent()
	if main_node.has_method("start_run"):
		main_node.call("start_run")
	else:
		GameManager.start_run()
	AudioManager.start_music()

func _on_run_started() -> void:
	_show_only(hud)

func _on_score(score: int, coins: int, distance_m: float) -> void:
	if score_label != null:
		score_label.text = "স্কোর: %d" % score
	if coins_label != null:
		coins_label.text = "🪙 %d" % coins
	if distance_label != null:
		distance_label.text = "%.0f মি" % distance_m

func _on_police(gap: float) -> void:
	if police_bar != null:
		police_bar.value = gap
	if police_label != null:
		if gap < 6.0:
			police_label.text = "⚠ পুলিশ খুব কাছে!"
		elif gap < 10.0:
			police_label.text = "পুলিশ পেছনে আছে"
		else:
			police_label.text = "পুলিশ দূরে আছে"

func _on_powerup(active: Dictionary) -> void:
	if powerup_label == null:
		return
	if active.is_empty():
		powerup_label.text = ""
	else:
		var parts: Array = []
		for k in active.keys():
			parts.append("%s %.0fs" % [k, float(active[k])])
		powerup_label.text = " | ".join(parts)

func _on_subtitle(text: String, speaker: String) -> void:
	if subtitle_label != null:
		subtitle_label.text = "%s: %s" % [speaker, text]
		subtitle_timer = 3.0

func _on_game_over(final_score: int, coins: int, distance_m: float, is_new_best: bool) -> void:
	_show_only(game_over_panel)
	var best_note := " 🎉 নতুন রেকর্ড!" if is_new_best else ""
	if game_over_label != null:
		game_over_label.text = "দৌড় শেষ, এবার জবাব দেওয়ার পালা!%s\n\nস্কোর: %d\nকয়েন: %d\nদূরত্ব: %.0f মি\nসেরা: %d" % [best_note, final_score, coins, distance_m, SaveSystem.best_score]
	AudioManager.stop_music()

func _on_missions(missions: Array) -> void:
	if mission_panel == null:
		return
	# Mission labels are added below the title; old dynamic labels are
	# kept simple by appending fresh ones on each update only if the
	# panel has just its title + back button (first build).
	# To avoid duplicates on repeated updates, do nothing if labels exist.
	if mission_panel.get_child_count() > 3:
		return
	var y := 200.0
	for m in missions:
		var status := "✓ সম্পন্ন" if m["done"] else "%d / %d" % [int(m["progress"]), int(m["target"])]
		_label(mission_panel, "%s — %s (পুরস্কার %d কয়েন)" % [m["title"], status, int(m["reward"])], y, 24)
		y += 70.0

func _process(delta: float) -> void:
	if subtitle_timer > 0.0:
		subtitle_timer -= delta
		if subtitle_timer <= 0.0 and subtitle_label != null:
			subtitle_label.text = ""
