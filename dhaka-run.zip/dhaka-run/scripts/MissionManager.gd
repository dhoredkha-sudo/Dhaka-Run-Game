extends Node
## Missions + outfits. Offline only. Daily missions are derived from
## the device date, so they work without any server or login.
## A mission is only marked complete when its counter actually reaches
## the target in a real run — the button in the UI never grants a
## reward by itself (see UIManager: it only shows claimed state).

signal missions_updated(missions: Array)

var daily_missions: Array = []
var _run_coins: int = 0

func _ready() -> void:
	_generate_daily()

func _generate_daily() -> void:
	var d := Time.get_date_dict_from_system()
	var seed := int(d["day"]) * 31 + int(d["month"]) * 7 + int(d["year"]) % 100
	# Deterministic rotation, not random per launch, so the day's list is stable.
	var pool := [
		{"id": "coins_100", "title": "১০০ কয়েন সংগ্রহ করো", "target": 100, "reward": 50},
		{"id": "run_60s", "title": "৬০ সেকেন্ড দৌড়াও", "target": 60, "reward": 40},
		{"id": "dodge_20", "title": "২০টি বাধা এড়াও", "target": 20, "reward": 40},
		{"id": "no_hit", "title": "কোনো ধাক্কা ছাড়া একটি রান শেষ করো", "target": 1, "reward": 80},
		{"id": "distance_500", "title": "৫০০ মিটার দৌড়াও", "target": 500, "reward": 50},
	]
	daily_missions.clear()
	for i in range(3):
		var m: Dictionary = pool[(seed + i) % pool.size()].duplicate()
		m["progress"] = 0
		m["done"] = _is_done_today(m["id"])
		daily_missions.append(m)
	missions_updated.emit(daily_missions)

func _today_key(mission_id: String) -> String:
	var d := Time.get_date_dict_from_system()
	return "%d-%02d-%02d_%s" % [d["year"], d["month"], d["day"], mission_id]

func _is_done_today(mission_id: String) -> bool:
	return SaveSystem.completed_missions.get(_today_key(mission_id), false)

func on_run_start() -> void:
	_run_coins = 0

func on_run_end(_score: int, coins: int, distance_m: float, run_time: float, dodged: int, collisions: int) -> void:
	_run_coins = coins
	var changed := false
	for m in daily_missions:
		if m["done"]:
			continue
		match m["id"]:
			"coins_100":
				m["progress"] = coins
			"run_60s":
				m["progress"] = int(run_time)
			"dodge_20":
				m["progress"] = dodged
			"distance_500":
				m["progress"] = int(distance_m)
			"no_hit":
				# Only counts if the run actually lasted and had no hit.
				if collisions == 0 and run_time >= 20.0:
					m["progress"] = 1
		if int(m["progress"]) >= int(m["target"]):
			m["done"] = true
			SaveSystem.completed_missions[_today_key(m["id"])] = true
			SaveSystem.add_coins(int(m["reward"]))
			changed = true
	if changed:
		SaveSystem.save_game()
	missions_updated.emit(daily_missions)

# Outfits: fictional only. Price in coins earned in-game.
func outfit_catalog() -> Array:
	return [
		{"id": "street_default", "name": "স্ট্রিট ডিফল্ট", "price": 0, "color": Color(0.9, 0.55, 0.2)},
		{"id": "panjabi_green", "name": "সবুজ পাঞ্জাবি", "price": 150, "color": Color(0.1, 0.6, 0.3)},
		{"id": "hoodie_night", "name": "নাইট হুডি", "price": 300, "color": Color(0.15, 0.15, 0.35)},
		{"id": "rain_jacket", "name": "বৃষ্টির জ্যাকেট", "price": 250, "color": Color(0.9, 0.8, 0.1)},
		{"id": "bazaar_kurta", "name": "বাজার কুর্তা", "price": 200, "color": Color(0.7, 0.2, 0.4)},
	]
