extends Node
## Central run state. This is NOT a placeholder: score, speed ramp,
## police distance, power-up timers and game-over are all driven here.

signal score_changed(score: int, coins: int, distance_m: float)
signal police_distance_changed(gap: float)
signal powerup_changed(active: Dictionary)
signal game_over(final_score: int, coins: int, distance_m: float, is_new_best: bool)
signal run_started
signal run_paused(paused: bool)

enum RunState { MENU, PLAYING, PAUSED, GAME_OVER }

var state: RunState = RunState.MENU
var score: int = 0
var coins: int = 0
var distance_m: float = 0.0
var run_time: float = 0.0
var obstacles_dodged: int = 0
var near_misses: int = 0
var collisions_this_run: int = 0

# Difficulty / speed
var base_speed: float = 12.0
var speed: float = 12.0
var max_speed: float = 32.0
var speed_gain_per_sec: float = 0.18

# Police pursuer gap (metres behind the player). Catch at <= 2.5.
var police_gap: float = 12.0
var police_gap_min: float = 2.5
var police_gap_max: float = 18.0
var police_catch_gap: float = 2.5

# Power-ups: name -> seconds remaining
var powerups: Dictionary = {}

func start_run() -> void:
	score = 0
	coins = 0
	distance_m = 0.0
	run_time = 0.0
	obstacles_dodged = 0
	near_misses = 0
	collisions_this_run = 0
	speed = base_speed
	police_gap = 12.0
	powerups.clear()
	state = RunState.PLAYING
	run_started.emit()
	DialogueManager.say("chase_start")
	MissionManager.on_run_start()

func _process(delta: float) -> void:
	if state != RunState.PLAYING:
		return
	run_time += delta
	# Slow-motion power-up slows the *world* speed, not the UI clock.
	var time_scale := 1.0
	if has_powerup("slowmo"):
		time_scale = 0.45
	speed = min(max_speed, base_speed + run_time * speed_gain_per_sec)
	if has_powerup("speed_boost"):
		speed += 8.0
	var effective_speed := speed * time_scale
	distance_m += effective_speed * delta
	score = int(distance_m * 2) + coins * 10 + near_misses * 25
	# Tick power-up timers.
	var expired: Array = []
	for key in powerups.keys():
		powerups[key] -= delta
		if powerups[key] <= 0.0:
			expired.append(key)
	for key in expired:
		powerups.erase(key)
	if not expired.is_empty():
		powerup_changed.emit(powerups.duplicate())
	score_changed.emit(score, coins, distance_m)
	police_distance_changed.emit(police_gap)

func add_coin() -> void:
	coins += 1
	AudioManager.play_sfx("coin")
	if coins % 25 == 0:
		DialogueManager.say("special_item")

func add_special_item() -> void:
	# Special items (e.g. a dropped wallet / trophy in the story) give a gap bonus.
	coins += 5
	police_gap = min(police_gap_max, police_gap + 1.5)
	DialogueManager.say("special_item")
	AudioManager.play_sfx("coin")

func register_dodge() -> void:
	obstacles_dodged += 1

func register_near_miss() -> void:
	near_misses += 1
	police_gap = min(police_gap_max, police_gap + 0.4)
	DialogueManager.say("near_miss")
	AudioManager.play_sfx("near_miss")

func register_collision() -> void:
	if has_powerup("shield"):
		powerups.erase("shield")
		powerup_changed.emit(powerups.duplicate())
		DialogueManager.say("near_miss")
		AudioManager.play_sfx("shield_hit")
		return
	collisions_this_run += 1
	police_gap -= 4.0
	AudioManager.play_sfx("hit")
	DialogueManager.say("close_police")
	police_distance_changed.emit(police_gap)
	if police_gap <= police_catch_gap:
		end_run()

func activate_powerup(kind: String, duration: float) -> void:
	if kind == "distractor":
		police_gap = min(police_gap_max, police_gap + 5.0)
		DialogueManager.say("special_item")
		return
	powerups[kind] = duration
	powerup_changed.emit(powerups.duplicate())
	AudioManager.play_sfx("powerup")

func has_powerup(kind: String) -> bool:
	return powerups.has(kind)

func pause_toggle() -> void:
	if state == RunState.PLAYING:
		state = RunState.PAUSED
		run_paused.emit(true)
	elif state == RunState.PAUSED:
		state = RunState.PLAYING
		run_paused.emit(false)

func end_run() -> void:
	if state != RunState.PLAYING:
		return
	state = RunState.GAME_OVER
	var is_new_best := score > SaveSystem.best_score
	if is_new_best:
		SaveSystem.best_score = score
	if distance_m > SaveSystem.best_distance:
		SaveSystem.best_distance = distance_m
	SaveSystem.add_coins(coins)
	SaveSystem.save_game()
	MissionManager.on_run_end(score, coins, distance_m, run_time, obstacles_dodged, collisions_this_run)
	DialogueManager.say("lose")
	if is_new_best:
		DialogueManager.say("highscore")
	AudioManager.play_sfx("game_over")
	game_over.emit(score, coins, distance_m, is_new_best)

func to_menu() -> void:
	state = RunState.MENU
