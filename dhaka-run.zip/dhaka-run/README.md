# ঢাকা রান — পুলিশের ধাওয়া / DHAKA RUN: POLICE CHASE

A complete, playable 3D endless runner for Android, built in **Godot 4.2**
with GDScript. No external 3D models, no copied movie dialogue, no real
logos, no real persons. All characters, shop names, brands and dialogue
lines in this project are fictional and original.

> **Honest delivery note — read first**
>
> This folder is the **complete runnable project source**, not an APK.
> This environment has no Godot editor, no Android SDK and no signing
> keystore installed, so no APK/AAB was built or tested here, and none
> is claimed. Follow §4 below on a PC with Godot 4.2 to build the APK
> yourself — the export preset in this repo is already configured for
> portrait Android, `com.dhakarun.policechase`, arm64.
>
> If you only have a phone, you cannot build a Godot Android APK from
> the phone alone. You need a PC (or a cloud PC) with Godot once; after
> that one build, the APK installs on any Android phone and the game
> itself works fully offline.
>
> **What was actually checked here (Godot 4.2.2, headless, 2026-10-30):**
> project import = no script parse errors (4 inference errors found
> and fixed during that check); a temporary in-game test run started
> correctly (state = PLAYING, score/distance increased), and 3
> collisions moved the police gap 12 → 8 → 0 and ended the run
> (state = GAME_OVER), exactly as designed. The headless dummy
> renderer also printed `mesh_get_surface_count: m is null` warnings
> — those are dummy-renderer warnings, not script errors, and do not
> appear as gameplay errors; still, run §5 on a real phone before
> calling the APK final. The temporary test script was removed
> before packaging, so it is not in this zip.

## 1. What is actually implemented (Phase 1–3)

### Core gameplay — Phase 1
- 3 lanes, swipe left/right, swipe up = jump, swipe down = slide.
  Keyboard for desktop testing: ←/→ or A/D, ↑/W/Space, ↓/S.
- Automatic forward running, speed ramps 12 → 32 m/s over time.
- Jump gravity + fast-fall on swipe-down in air, slide timer 0.7 s.
- Collision by lane + Z-distance + jump/slide state (deterministic,
  no physics tuning needed on a phone).
- Full-height obstacles (bus, CNG, rickshaw) must be dodged by lane
  change; barrier = jump; fruit cart = slide or jump; puddle = stumble
  only, never a run-ender.
- Police pursuer: gap starts 12 m, −4 m per hit, +0.4 m per near miss,
  +5 m for Police Distractor. Caught at ≤ 2.5 m → comedic game-over.
- Object pooling pattern: road segments are recycled, obstacles are
  freed only after passing behind the police, not every frame.

### Bangladeshi environment — Phase 2
- 6 rotating themes, every ~300 m: Old Dhaka, Commercial Road,
  Flyover, Local Bazaar, Rain Street, Night Market.
- Procedural road segments: road slab, lane dashes, side buildings,
  streetlights, fictional Bangla shop signs via `Label3D`
  (e.g. “আল-মদিনা চা ঘর”, “স্বপ্ন বাজার” — all fictional).
- Rain theme adds glossy puddle discs (metallic material, no
  real-time reflections, for mobile performance).
- Characters are procedural 3D figures (capsule/box/sphere meshes):
  Runner (orange shirt) with run/swing/lean/squash/stumble/panic-head
  animation; Police (blue uniform + cap) with confident lean run.
  No actor faces are copied. For a production release, replace these
  meshes with rigged models — the controller scripts already expose
  `Body/Head/LegL/LegR/ArmL/ArmR` by name, so a rigged model can be
  swapped in without changing gameplay code.

### Dialogue, menus, missions, power-ups — Phase 3
- **41 original short Bangla lines** in `scripts/DialogueManager.gd`,
  grouped: chase_start (6), close_police (6), near_miss (5),
  special_item (5), new_env (6), jump (4), lose (5), highscore (4).
  Contextual triggers + per-context cooldowns (no spam).
  Subtitles are always shown; voice is optional — drop a
  `res://audio/voices/<context>.wav` file in and it plays.
- Power-ups (all with HUD timer): Speed Boost (5 s), Coin Magnet
  (8 s), Shield (12 s, absorbs one hit), Slow Motion (4 s, world
  ×0.45), Police Distractor (+5 m gap instantly).
- Screens: Splash is the Main Menu title block (no separate splash
  scene is faked — the menu *is* the first screen), Main Menu,
  Character Selection, Outfit Selection, Missions, Settings,
  Gameplay HUD (score, coins, distance, police bar, power-ups,
  pause), Pause Menu, Game Over, High Scores.
- Daily missions (offline, date-derived): 3 per day, e.g. 100 coins,
  60 s run, 20 dodges, no-hit run, 500 m. Rewards are granted only
  by `MissionManager.on_run_end()` when a real run meets the target.
  The UI never grants coins by button press.
- Outfits (fictional, coin-priced): Street Default (free), Green
  Panjabi 150, Bazaar Kurta 200, Rain Jacket 250, Night Hoodie 300.
  Buying checks `SaveSystem.spend_coins()` first.
- Local save only (`user://dhaka_run_save.cfg`): best score,
  best distance, total coins, unlocked/selected outfit, volumes.
  No login, no internet, no data leaves the device.

### Sound
- Original synthesized WAVs in `audio/` (coin, jump, slide, hit,
  shield_hit, powerup, near_miss, game_over, music_loop), generated
  by `tools/make_sounds.py` — no samples copied from anywhere.
- Separate music / SFX / dialogue volumes in `AudioManager`.
- Missing audio files are skipped, never crash. Replace any WAV with
  a licensed recording of the same filename to upgrade it.
- Siren, rickshaw bell, bus horn, crowd and rain ambience are
  **not yet recorded** — they are the documented next audio task
  (§6). Do not claim they exist in this build.

## 2. Project layout

```
dhaka-run/
  project.godot            # Godot 4.2, portrait 720x1280, mobile renderer
  export_presets.cfg       # Android preset, portrait, arm64, min SDK 21
  icon.svg                 # Original green/white icon, no logo copied
  scenes/Main.tscn         # Camera, light, environment, Player, Police, UI
  scripts/
    Main.gd                # Scene root, start_run() reset order
    PlayerController.gd    # Lanes, jump/slide, swipe, procedural animation
    PoliceAI.gd            # Follows player + GameManager.police_gap
    RoadGenerator.gd       # Pooled segments, 6 themes, Bangla signs
    ObstacleSpawner.gd     # Rows, coins, power-ups, collision, near miss
    GameManager.gd         # Score, speed, police gap, power-up timers
    DialogueManager.gd     # 41 original Bangla lines + cooldowns
    AudioManager.gd        # Music/SFX/dialogue volumes, missing-file safe
    MissionManager.gd      # Daily missions, outfit catalogue
    SaveSystem.gd          # Local ConfigFile save
    UIManager.gd           # All screens, built in code (no UI assets needed)
  audio/*.wav              # Original synthesized sounds
  tools/make_sounds.py     # Regenerates audio/
```

## 3. Requirements

- **Godot 4.2.x** (stable). Newer 4.x may work, but 4.2 is the version
  this project was written against. Do not use Godot 3 — the scripts
  use Godot 4 syntax (`@export`, `Callable`, `Time.get_ticks_msec`).
- A PC for building. Android SDK + Godot Android export templates
  are needed only for the APK step (§4), not for playing in the editor.
- No other dependencies. No plugins, no paid assets.

## 4. Build the Android APK (PC, step by step)

1. Install Godot 4.2 from godotengine.org. Open Godot → Import →
   choose this `dhaka-run/` folder → Open. The editor will import
   `scenes/Main.tscn` as the main scene (already set in project.godot).
2. Press **Play** (F5) in the editor first. You should see the main
   menu. Press খেলুন. Test with keyboard arrows + Space (see §5).
   If the editor shows a script error, do not export yet — fix that
   error first; an APK built from a broken project will also be broken.
3. Editor → Manage Export Templates → Download the 4.2 templates
   (one-time, needs internet).
4. Project → Install Android Build Template (only if you need a
   custom Gradle build; the default template is enough for this game).
5. Project → Export → Android → check the preset already in this
   repo (name “Android”, package `com.dhakarun.policechase`).
   For a **test build**: enable “Use Debug Keystore”.
   For **release**: create your own keystore in the editor and fill
   the release keystore fields. Never share the keystore or its
   password in chat or in the repo.
6. Export Project → save as `DhakaRun.apk` → install on the phone
   (allow “Install unknown apps” for the file manager / browser you
   use, then install). The game needs no permissions except Vibrate
   (declared in the preset) and works offline.

## 5. Testing checklist (do this before calling it “done”)

- [ ] Menu → খেলুন starts a run, HUD shows score/coins/distance.
- [ ] Swipe left/right changes lane smoothly; up jumps over a barrier;
      down slides under a cart; a bus in your lane without a lane
      change costs police distance.
- [ ] Police bar drops on a hit, rises on a near miss; 3–4 hits in a
      row without recovery ends the run with the game-over line
      “দৌড় শেষ, এবার জবাব দেওয়ার পালা!”
- [ ] Coins increase the coin counter; magnet visibly pulls coins.
- [ ] Shield absorbs exactly one hit, then disappears from the HUD.
- [ ] After ~300 m the theme changes and a new-environment subtitle appears.
- [ ] Pause → Resume continues the same run; Restart resets score,
      coins, distance and police gap to 12 m.
- [ ] Close and reopen: best score and coins persist (local save).
- [ ] On a mid-range phone, frame rate stays smooth with shadows off
      (default). If it stutters, lower the editor's rendering scale
      or reduce `SEGMENTS_AHEAD` in `RoadGenerator.gd` from 8 to 6.

## 6. What is NOT in this build (honest limits)

- No APK/AAB built or device-tested here (see top note).
- No rigged / motion-captured character models — characters are
  procedural primitives with code-driven limb swing. This is a
  playable vertical slice, not a final art pass.
- No recorded Bengali voice acting, siren, horn, bell, crowd or rain
  recordings — subtitles + synthesized SFX only. Voice files can be
  added later under `audio/voices/` without code changes.
- No real live video, no online leaderboards, no ads, no in-app
  purchases, no revive — and no button pretends otherwise.
- Bangla font: Godot uses the system/default font for UI and
  `Label3D` signs. On a device where Bangla rendering is broken,
  add a Bengali font (e.g. Noto Sans Bengali, OFL licensed) to
  `fonts/` and set it as the theme font in `UIManager` / sign labels.
  That font file is intentionally **not** bundled here until you
  choose the exact licensed file you want to ship.

## 7. Phase 4 — next steps, in order

1. Play-test in the editor, fix any script error, then build one
   debug APK and run the §5 checklist on a real phone.
2. Record / license siren, bell, horn, crowd, rain ambience and
   Bengali voice lines; drop them into `audio/` by filename.
3. Replace procedural characters with rigged models (same node names).
4. Add a Bengali font file + Settings volume sliders (the Settings
   screen currently states this limit plainly instead of faking sliders).
5. Profile on a mid-range device; only then enable shadows or
   higher segment counts.
6. Release build with your own keystore; never reuse a debug keystore
   for a store release.

## 8. Story note

The chase is fictional entertainment. The runner is a fictional
character, the officer is a fictional officer, and the game never
presents theft as admirable or instructions for real wrongdoing.
Game-over text is comedic and non-graphic, by design.
