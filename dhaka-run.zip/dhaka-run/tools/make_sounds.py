#!/usr/bin/env python3
"""Generate the original sound effects shipped with Dhaka Run.
All sounds are synthesized here from sine waves / noise — no samples
are copied from anywhere, so there is nothing to license.
Run: python3 tools/make_sounds.py  (writes res://audio/*.wav)
"""
import math, random, struct, wave, os

SR = 22050
OUT = os.path.join(os.path.dirname(__file__), "..", "audio")
os.makedirs(OUT, exist_ok=True)

def write(name, samples):
    path = os.path.join(OUT, name + ".wav")
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        frames = b"".join(struct.pack("<h", max(-32767, min(32767, int(s * 30000)))) for s in samples)
        w.writeframes(frames)
    print(name, len(samples))

def sine(freq, dur, amp=0.5, slide_to=None):
    n = int(SR * dur)
    out = []
    for i in range(n):
        f = freq if slide_to is None else freq + (slide_to - freq) * i / max(1, n)
        out.append(amp * math.sin(2 * math.pi * f * i / SR))
    return out

def noise(dur, amp=0.3):
    random.seed(42)
    return [amp * (random.random() * 2 - 1) * (1 - i / (SR * dur)) for i in range(int(SR * dur))]

def seq(*parts):
    out = []
    for p in parts:
        out.extend(p)
    return out

write("coin", seq(sine(880, 0.08), sine(1320, 0.12)))
write("jump", sine(300, 0.25, slide_to=700))
write("slide", noise(0.3, 0.25))
write("hit", seq(sine(120, 0.2, amp=0.8, slide_to=60), noise(0.1, 0.2)))
write("shield_hit", seq(sine(600, 0.1), sine(900, 0.15)))
write("powerup", seq(sine(523, 0.1), sine(659, 0.1), sine(784, 0.15)))
write("near_miss", noise(0.2, 0.2))
write("game_over", seq(sine(400, 0.2), sine(300, 0.2), sine(200, 0.4)))
# Simple 8-second music loop: C - Am - F - G arpeggio, sine only.
notes = [261.6, 329.6, 392.0, 440.0, 220.0, 261.6, 329.6, 392.0, 174.6, 220.0, 261.6, 349.2, 196.0, 246.9, 293.7, 392.0]
music = []
for f in notes:
    music.extend(sine(f, 0.5, amp=0.18))
write("music_loop", music)
print("Done. Replace any .wav with a licensed recording of the same name to change it.")
